﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class Requested : MetroFramework.Forms.MetroForm
    {
        public Requested()
        {
            InitializeComponent();
        }
        public void LoadRequestedInfo()
        {
            try
            {
                string query = "select * from Requested";

                DataTable dt = DataAccess.GetDataTable(query);


                dgvRequestedinfo.AutoGenerateColumns = false;
                dgvRequestedinfo.DataSource = dt;
                dgvRequestedinfo.Refresh();
                dgvRequestedinfo.ClearSelection();
            }

            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        private void Requested_Load(object sender, EventArgs e)
        {
            this.Init();
        }
        private void Init()
        {
            this.LoadRequestedInfo();
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            AdminFrame a1 = new AdminFrame();
            a1.Show();
            this.Visible = false;
        }
    }
}
