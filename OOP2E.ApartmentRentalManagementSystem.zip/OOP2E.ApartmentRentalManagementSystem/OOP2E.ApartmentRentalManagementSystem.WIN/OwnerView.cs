﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class OwnerView : MetroFramework.Forms.MetroForm
    {
        public OwnerView()
        {
            InitializeComponent();
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            AddNewApartment anp1 = new AddNewApartment();
            anp1.Show();
            this.Visible = false;
        }

        private void MetroButton2_Click(object sender, EventArgs e)
        {
            Requested r1 = new Requested();
            r1.Show();
            this.Visible = false;
        }
    }
}
