﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class Apartments : MetroFramework.Forms.MetroForm
    {
        public Apartments()
        {
            InitializeComponent();
        }
        public void LoadApartmentInfo()
        {
            try
            {
                string query = "select * from Apartment";

                DataTable dt = DataAccess.GetDataTable(query);


                dgvApartments.AutoGenerateColumns = false;
                dgvApartments.DataSource = dt;
                dgvApartments.Refresh();
                dgvApartments.ClearSelection();
            }

            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void MetroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Apartments_Load(object sender, EventArgs e)

            {
                this.Init();
            }

            private void Init()
            {
                this.LoadApartmentInfo();
            }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            AdminFrame a1 = new AdminFrame();
            a1.Show();
            this.Visible = false;
        }
    }
}
