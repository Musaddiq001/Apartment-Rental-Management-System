﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class Owner : MetroFramework.Forms.MetroForm
    {
        public Owner()
        {
            InitializeComponent();
        }
        public void LoadOwnerInfo()
        {
            try
            {
                string query = "select ID,Name,Address,Email from userinfo where Type='Owner'";

                DataTable dt = DataAccess.GetDataTable(query);


                dgvOwnerinfo.AutoGenerateColumns = false;
                dgvOwnerinfo.DataSource = dt;
                dgvOwnerinfo.Refresh();
                dgvOwnerinfo.ClearSelection();
            }

            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        private void Owner_Load(object sender, EventArgs e)
        {
            this.Init();
        }

        private void Init()
        {
            this.LoadOwnerInfo();
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            AdminFrame a1 = new AdminFrame();
            a1.Show();
            this.Visible = false;
        }
    }
}
