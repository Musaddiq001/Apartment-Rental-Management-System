﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class SignUp : MetroFramework.Forms.MetroForm
    {

        public SignUp()
        {
            InitializeComponent();
            btnbackAdmin.Visible = false;
        }
        public SignUp(int b)
        {

            InitializeComponent();
            btnBacklog.Visible = false;
        }

        private void MetroButton2_Click(object sender, EventArgs e)
        {
            Loginform l1 = new Loginform();
            l1.Visible=true;
            this.Visible=false;

        }

        private void MetroButton2_Click_1(object sender, EventArgs e)
        {
            Loginform l1 = new Loginform();
            l1.Show();
            this.Hide();

        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            this.insert();

        }
        private void insert()
        {
            string query = "insert into userinfo(Name,[Password],[Address],Email,[Type]) " +
                "values ('" + txtUN.Text + "'," + Int32.Parse(txtPass.Text) + ",'" + rtxtAddress.Text + "','"+ txtEmail.Text+ "','" + txtUN.Text + "'); ";
            int ID = DataAccess.InsertQuery(query);
            txtID.Text = ID.ToString();
            MessageBox.Show("Saved");
           
        }

        private void BtnbackAdmin_Click(object sender, EventArgs e)
        {
            AdminFrame a1 = new AdminFrame();
            a1.Show();
            this.Visible = false;

        }

        // private void update()
        //{
        //  string query = "Update studentinfo set Name ='" + txtName.Text + "'Dept='" + txtDept.Text + "'Credit='" + txtCredit.Text + "' +" + "'CGPA='" +txtCgpa.Text +
        //    " where ID = " + txtID.Text + "";
        //DataAccess.ExecuteQuery(query);
        //MetroFramework.MetroMessageBox.Show(owner: this, message: "operation complete");
        //}
        //}
    }
}
