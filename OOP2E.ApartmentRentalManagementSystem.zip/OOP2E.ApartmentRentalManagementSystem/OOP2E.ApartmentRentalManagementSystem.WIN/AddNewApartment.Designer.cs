﻿namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    partial class AddNewApartment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.txtOwnerId = new MetroFramework.Controls.MetroTextBox();
            this.txtLoc = new MetroFramework.Controls.MetroTextBox();
            this.txtBed = new MetroFramework.Controls.MetroTextBox();
            this.txtBath = new MetroFramework.Controls.MetroTextBox();
            this.txtBalcony = new MetroFramework.Controls.MetroTextBox();
            this.txtPrice = new MetroFramework.Controls.MetroTextBox();
            this.txtFloor = new MetroFramework.Controls.MetroTextBox();
            this.txtType = new MetroFramework.Controls.MetroTextBox();
            this.txtStatus = new MetroFramework.Controls.MetroTextBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.txtAP_ID = new MetroFramework.Controls.MetroTextBox();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(77, 112);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(75, 20);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Owner ID :";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(84, 147);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(68, 20);
            this.metroLabel2.TabIndex = 1;
            this.metroLabel2.Text = "Location :";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(112, 179);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(40, 20);
            this.metroLabel3.TabIndex = 2;
            this.metroLabel3.Text = "Bed :";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(109, 214);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(43, 20);
            this.metroLabel4.TabIndex = 3;
            this.metroLabel4.Text = "Bath :";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(88, 252);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(64, 20);
            this.metroLabel5.TabIndex = 4;
            this.metroLabel5.Text = "Balcony :";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(105, 291);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(47, 20);
            this.metroLabel6.TabIndex = 5;
            this.metroLabel6.Text = "Price :";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(105, 322);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(47, 20);
            this.metroLabel7.TabIndex = 6;
            this.metroLabel7.Text = "Floor :";
            this.metroLabel7.Click += new System.EventHandler(this.MetroLabel7_Click);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(100, 388);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(52, 20);
            this.metroLabel8.TabIndex = 7;
            this.metroLabel8.Text = "Status :";
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(106, 357);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(46, 20);
            this.metroLabel9.TabIndex = 8;
            this.metroLabel9.Text = "Type :";
            // 
            // txtOwnerId
            // 
            // 
            // 
            // 
            this.txtOwnerId.CustomButton.Image = null;
            this.txtOwnerId.CustomButton.Location = new System.Drawing.Point(98, 1);
            this.txtOwnerId.CustomButton.Name = "";
            this.txtOwnerId.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtOwnerId.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtOwnerId.CustomButton.TabIndex = 1;
            this.txtOwnerId.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtOwnerId.CustomButton.UseSelectable = true;
            this.txtOwnerId.CustomButton.Visible = false;
            this.txtOwnerId.Lines = new string[0];
            this.txtOwnerId.Location = new System.Drawing.Point(198, 109);
            this.txtOwnerId.MaxLength = 32767;
            this.txtOwnerId.Name = "txtOwnerId";
            this.txtOwnerId.PasswordChar = '\0';
            this.txtOwnerId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtOwnerId.SelectedText = "";
            this.txtOwnerId.SelectionLength = 0;
            this.txtOwnerId.SelectionStart = 0;
            this.txtOwnerId.ShortcutsEnabled = true;
            this.txtOwnerId.Size = new System.Drawing.Size(120, 23);
            this.txtOwnerId.TabIndex = 9;
            this.txtOwnerId.UseSelectable = true;
            this.txtOwnerId.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtOwnerId.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtLoc
            // 
            // 
            // 
            // 
            this.txtLoc.CustomButton.Image = null;
            this.txtLoc.CustomButton.Location = new System.Drawing.Point(98, 1);
            this.txtLoc.CustomButton.Name = "";
            this.txtLoc.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtLoc.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtLoc.CustomButton.TabIndex = 1;
            this.txtLoc.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtLoc.CustomButton.UseSelectable = true;
            this.txtLoc.CustomButton.Visible = false;
            this.txtLoc.Lines = new string[0];
            this.txtLoc.Location = new System.Drawing.Point(198, 147);
            this.txtLoc.MaxLength = 32767;
            this.txtLoc.Name = "txtLoc";
            this.txtLoc.PasswordChar = '\0';
            this.txtLoc.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLoc.SelectedText = "";
            this.txtLoc.SelectionLength = 0;
            this.txtLoc.SelectionStart = 0;
            this.txtLoc.ShortcutsEnabled = true;
            this.txtLoc.Size = new System.Drawing.Size(120, 23);
            this.txtLoc.TabIndex = 10;
            this.txtLoc.UseSelectable = true;
            this.txtLoc.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtLoc.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtBed
            // 
            // 
            // 
            // 
            this.txtBed.CustomButton.Image = null;
            this.txtBed.CustomButton.Location = new System.Drawing.Point(98, 1);
            this.txtBed.CustomButton.Name = "";
            this.txtBed.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtBed.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBed.CustomButton.TabIndex = 1;
            this.txtBed.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBed.CustomButton.UseSelectable = true;
            this.txtBed.CustomButton.Visible = false;
            this.txtBed.Lines = new string[0];
            this.txtBed.Location = new System.Drawing.Point(198, 179);
            this.txtBed.MaxLength = 32767;
            this.txtBed.Name = "txtBed";
            this.txtBed.PasswordChar = '\0';
            this.txtBed.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBed.SelectedText = "";
            this.txtBed.SelectionLength = 0;
            this.txtBed.SelectionStart = 0;
            this.txtBed.ShortcutsEnabled = true;
            this.txtBed.Size = new System.Drawing.Size(120, 23);
            this.txtBed.TabIndex = 11;
            this.txtBed.UseSelectable = true;
            this.txtBed.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBed.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtBath
            // 
            // 
            // 
            // 
            this.txtBath.CustomButton.Image = null;
            this.txtBath.CustomButton.Location = new System.Drawing.Point(98, 1);
            this.txtBath.CustomButton.Name = "";
            this.txtBath.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtBath.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBath.CustomButton.TabIndex = 1;
            this.txtBath.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBath.CustomButton.UseSelectable = true;
            this.txtBath.CustomButton.Visible = false;
            this.txtBath.Lines = new string[0];
            this.txtBath.Location = new System.Drawing.Point(198, 214);
            this.txtBath.MaxLength = 32767;
            this.txtBath.Name = "txtBath";
            this.txtBath.PasswordChar = '\0';
            this.txtBath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBath.SelectedText = "";
            this.txtBath.SelectionLength = 0;
            this.txtBath.SelectionStart = 0;
            this.txtBath.ShortcutsEnabled = true;
            this.txtBath.Size = new System.Drawing.Size(120, 23);
            this.txtBath.TabIndex = 12;
            this.txtBath.UseSelectable = true;
            this.txtBath.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBath.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtBalcony
            // 
            // 
            // 
            // 
            this.txtBalcony.CustomButton.Image = null;
            this.txtBalcony.CustomButton.Location = new System.Drawing.Point(98, 1);
            this.txtBalcony.CustomButton.Name = "";
            this.txtBalcony.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtBalcony.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBalcony.CustomButton.TabIndex = 1;
            this.txtBalcony.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBalcony.CustomButton.UseSelectable = true;
            this.txtBalcony.CustomButton.Visible = false;
            this.txtBalcony.Lines = new string[0];
            this.txtBalcony.Location = new System.Drawing.Point(198, 252);
            this.txtBalcony.MaxLength = 32767;
            this.txtBalcony.Name = "txtBalcony";
            this.txtBalcony.PasswordChar = '\0';
            this.txtBalcony.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBalcony.SelectedText = "";
            this.txtBalcony.SelectionLength = 0;
            this.txtBalcony.SelectionStart = 0;
            this.txtBalcony.ShortcutsEnabled = true;
            this.txtBalcony.Size = new System.Drawing.Size(120, 23);
            this.txtBalcony.TabIndex = 13;
            this.txtBalcony.UseSelectable = true;
            this.txtBalcony.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBalcony.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtPrice
            // 
            // 
            // 
            // 
            this.txtPrice.CustomButton.Image = null;
            this.txtPrice.CustomButton.Location = new System.Drawing.Point(98, 1);
            this.txtPrice.CustomButton.Name = "";
            this.txtPrice.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtPrice.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPrice.CustomButton.TabIndex = 1;
            this.txtPrice.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPrice.CustomButton.UseSelectable = true;
            this.txtPrice.CustomButton.Visible = false;
            this.txtPrice.Lines = new string[0];
            this.txtPrice.Location = new System.Drawing.Point(198, 291);
            this.txtPrice.MaxLength = 32767;
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.PasswordChar = '\0';
            this.txtPrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPrice.SelectedText = "";
            this.txtPrice.SelectionLength = 0;
            this.txtPrice.SelectionStart = 0;
            this.txtPrice.ShortcutsEnabled = true;
            this.txtPrice.Size = new System.Drawing.Size(120, 23);
            this.txtPrice.TabIndex = 14;
            this.txtPrice.UseSelectable = true;
            this.txtPrice.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPrice.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtFloor
            // 
            // 
            // 
            // 
            this.txtFloor.CustomButton.Image = null;
            this.txtFloor.CustomButton.Location = new System.Drawing.Point(98, 1);
            this.txtFloor.CustomButton.Name = "";
            this.txtFloor.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtFloor.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtFloor.CustomButton.TabIndex = 1;
            this.txtFloor.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtFloor.CustomButton.UseSelectable = true;
            this.txtFloor.CustomButton.Visible = false;
            this.txtFloor.Lines = new string[0];
            this.txtFloor.Location = new System.Drawing.Point(198, 322);
            this.txtFloor.MaxLength = 32767;
            this.txtFloor.Name = "txtFloor";
            this.txtFloor.PasswordChar = '\0';
            this.txtFloor.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtFloor.SelectedText = "";
            this.txtFloor.SelectionLength = 0;
            this.txtFloor.SelectionStart = 0;
            this.txtFloor.ShortcutsEnabled = true;
            this.txtFloor.Size = new System.Drawing.Size(120, 23);
            this.txtFloor.TabIndex = 15;
            this.txtFloor.UseSelectable = true;
            this.txtFloor.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtFloor.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtType
            // 
            // 
            // 
            // 
            this.txtType.CustomButton.Image = null;
            this.txtType.CustomButton.Location = new System.Drawing.Point(98, 1);
            this.txtType.CustomButton.Name = "";
            this.txtType.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtType.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtType.CustomButton.TabIndex = 1;
            this.txtType.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtType.CustomButton.UseSelectable = true;
            this.txtType.CustomButton.Visible = false;
            this.txtType.Lines = new string[0];
            this.txtType.Location = new System.Drawing.Point(198, 354);
            this.txtType.MaxLength = 32767;
            this.txtType.Name = "txtType";
            this.txtType.PasswordChar = '\0';
            this.txtType.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtType.SelectedText = "";
            this.txtType.SelectionLength = 0;
            this.txtType.SelectionStart = 0;
            this.txtType.ShortcutsEnabled = true;
            this.txtType.Size = new System.Drawing.Size(120, 23);
            this.txtType.TabIndex = 16;
            this.txtType.UseSelectable = true;
            this.txtType.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtType.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtStatus
            // 
            // 
            // 
            // 
            this.txtStatus.CustomButton.Image = null;
            this.txtStatus.CustomButton.Location = new System.Drawing.Point(98, 1);
            this.txtStatus.CustomButton.Name = "";
            this.txtStatus.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtStatus.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtStatus.CustomButton.TabIndex = 1;
            this.txtStatus.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtStatus.CustomButton.UseSelectable = true;
            this.txtStatus.CustomButton.Visible = false;
            this.txtStatus.Lines = new string[0];
            this.txtStatus.Location = new System.Drawing.Point(198, 388);
            this.txtStatus.MaxLength = 32767;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.PasswordChar = '\0';
            this.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtStatus.SelectedText = "";
            this.txtStatus.SelectionLength = 0;
            this.txtStatus.SelectionStart = 0;
            this.txtStatus.ShortcutsEnabled = true;
            this.txtStatus.Size = new System.Drawing.Size(120, 23);
            this.txtStatus.TabIndex = 17;
            this.txtStatus.UseSelectable = true;
            this.txtStatus.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtStatus.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(665, 357);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 18;
            this.metroButton1.Text = "ADD";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.MetroButton1_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(528, 357);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(75, 23);
            this.metroButton2.TabIndex = 19;
            this.metroButton2.Text = "Back";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.MetroButton2_Click);
            // 
            // txtAP_ID
            // 
            // 
            // 
            // 
            this.txtAP_ID.CustomButton.Image = null;
            this.txtAP_ID.CustomButton.Location = new System.Drawing.Point(98, 1);
            this.txtAP_ID.CustomButton.Name = "";
            this.txtAP_ID.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtAP_ID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAP_ID.CustomButton.TabIndex = 1;
            this.txtAP_ID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAP_ID.CustomButton.UseSelectable = true;
            this.txtAP_ID.CustomButton.Visible = false;
            this.txtAP_ID.Lines = new string[0];
            this.txtAP_ID.Location = new System.Drawing.Point(568, 85);
            this.txtAP_ID.MaxLength = 32767;
            this.txtAP_ID.Name = "txtAP_ID";
            this.txtAP_ID.PasswordChar = '\0';
            this.txtAP_ID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAP_ID.SelectedText = "";
            this.txtAP_ID.SelectionLength = 0;
            this.txtAP_ID.SelectionStart = 0;
            this.txtAP_ID.ShortcutsEnabled = true;
            this.txtAP_ID.Size = new System.Drawing.Size(120, 23);
            this.txtAP_ID.TabIndex = 20;
            this.txtAP_ID.UseSelectable = true;
            this.txtAP_ID.Visible = false;
            this.txtAP_ID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAP_ID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // AddNewApartment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtAP_ID);
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.txtFloor);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtBalcony);
            this.Controls.Add(this.txtBath);
            this.Controls.Add(this.txtBed);
            this.Controls.Add(this.txtLoc);
            this.Controls.Add(this.txtOwnerId);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Name = "AddNewApartment";
            this.Text = "AddNewApartment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroTextBox txtOwnerId;
        private MetroFramework.Controls.MetroTextBox txtLoc;
        private MetroFramework.Controls.MetroTextBox txtBed;
        private MetroFramework.Controls.MetroTextBox txtBath;
        private MetroFramework.Controls.MetroTextBox txtBalcony;
        private MetroFramework.Controls.MetroTextBox txtPrice;
        private MetroFramework.Controls.MetroTextBox txtFloor;
        private MetroFramework.Controls.MetroTextBox txtType;
        private MetroFramework.Controls.MetroTextBox txtStatus;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroTextBox txtAP_ID;
    }
}