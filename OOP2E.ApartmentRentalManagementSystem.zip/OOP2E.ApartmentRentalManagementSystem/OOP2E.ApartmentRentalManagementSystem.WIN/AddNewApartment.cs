﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class AddNewApartment : MetroFramework.Forms.MetroForm
    {
        public AddNewApartment()
        {
            InitializeComponent();
        }

        private void MetroLabel7_Click(object sender, EventArgs e)
        {

        }

        private void MetroButton2_Click(object sender, EventArgs e)
        {
            OwnerView ov1 = new OwnerView();
            ov1.Show();
            this.Visible = false;
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            this.insert();
        }
        private void insert()
        {
            string query = "insert into Apartment (ID, Location, Bed,Bath,Balcony,Price,[Floor],[Type],[Status]) " + 
                "values("+Int32.Parse(txtOwnerId.Text)+",'"+txtLoc.Text+ "'," + Int32.Parse(txtBed.Text) + ","+Int32.Parse(txtBath.Text)+","+Int32.Parse(txtBalcony.Text)+","+Int32.Parse(txtPrice.Text)+","+Int32.Parse(txtFloor.Text)+",'"+txtType.Text+"','"+txtStatus.Text+"'); ";
            int ID = DataAccess.InsertQuery(query);
            txtAP_ID.Text = ID.ToString();
            MessageBox.Show("Saved");

        }
    }
}
