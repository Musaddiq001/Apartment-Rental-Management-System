﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    class DataAccess
    {
            public static DataTable GetDataTable(string query)
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03GAJ6H\SQLEXPRESS;Initial Catalog=project;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);


                DataSet ds = new DataSet();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);

                DataTable dt = ds.Tables[0];

                return dt;
            }
            public static void ExecuteQuery(string query)
            {
                SqlConnection con = new SqlConnection(connectionString: @"Data Source=DESKTOP-03GAJ6H\SQLEXPRESS;Initial Catalog=project;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
            }
            public static int InsertQuery(string query)
            {
                SqlConnection con = new SqlConnection(connectionString: @"Data Source=DESKTOP-03GAJ6H\SQLEXPRESS;Initial Catalog=project;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();

                query = "select SCOPE_IDENTITY() as 'ID';";
                cmd.CommandText = query;

                DataSet ds = new DataSet();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                DataTable dt = ds.Tables[0];
                int id = Int32.Parse(dt.Rows[0]["ID"].ToString());
                return id;
            }

            public static string query { get; set; }
        }
}

