﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class Customer : MetroFramework.Forms.MetroForm
    {
        public Customer()
        {
            InitializeComponent();
        }
        public void LoadCustomerInfo()
        {
            try
            {
                string query = "select ID,Name,Address,Email from userinfo where Type='Customer'";
                
                DataTable dt = DataAccess.GetDataTable(query);


                dgvCustomerinfo.AutoGenerateColumns = false;
                dgvCustomerinfo.DataSource = dt;
                dgvCustomerinfo.Refresh();
                dgvCustomerinfo.ClearSelection();
            }

            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            this.Init();
        }

        private void Init()
        {
            this.LoadCustomerInfo();
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            AdminFrame a1 = new AdminFrame();
            a1.Show();
            this.Visible = false;
        }
    }
}
