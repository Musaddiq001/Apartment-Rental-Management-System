﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class AdminFrame : MetroFramework.Forms.MetroForm
    {
        public AdminFrame()
        {
            InitializeComponent();
        }

        private void MetroButton6_Click(object sender, EventArgs e)
        {
            int b = 1;
        
            SignUp sf1 = new SignUp(b);
            sf1.Show();
            this.Visible = false;
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            Customer c1 = new Customer();
            c1.Show();
            this.Visible = false;
        }

        private void MetroButton2_Click(object sender, EventArgs e)
        {
            Owner o1 = new Owner();
            o1.Show();
            this.Visible= false;
        }

        private void MetroButton3_Click(object sender, EventArgs e)
        {
            Apartments A1 = new Apartments();
            A1.Show();
            this.Visible = false;
        }

        private void MetroButton4_Click(object sender, EventArgs e)
        {
            Requested r1 = new Requested();
            r1.Show();
            this.Visible = false;
        }

        private void MetroButton5_Click(object sender, EventArgs e)
        {
            Reserved r1 = new Reserved();
            r1.Show();
            this.Visible = false;
        }

        private void AdminFrame_Load(object sender, EventArgs e)
        {

        }

        private void MetroButton7_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Visible = false;
        }
    }
}
