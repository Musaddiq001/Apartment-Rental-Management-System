﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class Reserved : MetroFramework.Forms.MetroForm
    {
        public Reserved()
        {
            InitializeComponent();
        }
        public void LoadReservedInfo()
        {
            try
            {
                string query = "select * from Reserved";

                DataTable dt = DataAccess.GetDataTable(query);


                dgvReservedInfo.AutoGenerateColumns = false;
                dgvReservedInfo.DataSource = dt;
                dgvReservedInfo.Refresh();
                dgvReservedInfo.ClearSelection();
            }

            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void Reserved_Load(object sender, EventArgs e)
        {
            this.Init();
        }
        private void Init()
        {
            this.LoadReservedInfo();
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            AdminFrame a1 = new AdminFrame();
            a1.Show();
            this.Visible = false;
        }
    }
}
