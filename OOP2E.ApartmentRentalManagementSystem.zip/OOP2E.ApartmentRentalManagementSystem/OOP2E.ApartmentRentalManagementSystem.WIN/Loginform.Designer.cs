﻿namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    partial class Loginform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txtUN = new MetroFramework.Controls.MetroTextBox();
            this.txtPass = new MetroFramework.Controls.MetroTextBox();
            this.loginAdmin = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.loginCustomer = new MetroFramework.Controls.MetroButton();
            this.loginOwner = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(202, 218);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(107, 25);
            this.metroLabel2.TabIndex = 1;
            this.metroLabel2.Text = "Password :";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(190, 181);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(119, 25);
            this.metroLabel3.TabIndex = 2;
            this.metroLabel3.Text = "User Name :";
            // 
            // txtUN
            // 
            // 
            // 
            // 
            this.txtUN.CustomButton.Image = null;
            this.txtUN.CustomButton.Location = new System.Drawing.Point(141, 1);
            this.txtUN.CustomButton.Name = "";
            this.txtUN.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtUN.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUN.CustomButton.TabIndex = 1;
            this.txtUN.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUN.CustomButton.UseSelectable = true;
            this.txtUN.CustomButton.Visible = false;
            this.txtUN.Lines = new string[0];
            this.txtUN.Location = new System.Drawing.Point(368, 183);
            this.txtUN.MaxLength = 32767;
            this.txtUN.Name = "txtUN";
            this.txtUN.PasswordChar = '\0';
            this.txtUN.PromptText = "Enter User Name";
            this.txtUN.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUN.SelectedText = "";
            this.txtUN.SelectionLength = 0;
            this.txtUN.SelectionStart = 0;
            this.txtUN.ShortcutsEnabled = true;
            this.txtUN.Size = new System.Drawing.Size(163, 23);
            this.txtUN.TabIndex = 4;
            this.txtUN.UseSelectable = true;
            this.txtUN.WaterMark = "Enter User Name";
            this.txtUN.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUN.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtUN.Click += new System.EventHandler(this.MetroTextBox1_Click);
            // 
            // txtPass
            // 
            // 
            // 
            // 
            this.txtPass.CustomButton.Image = null;
            this.txtPass.CustomButton.Location = new System.Drawing.Point(141, 1);
            this.txtPass.CustomButton.Name = "";
            this.txtPass.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtPass.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPass.CustomButton.TabIndex = 1;
            this.txtPass.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPass.CustomButton.UseSelectable = true;
            this.txtPass.CustomButton.Visible = false;
            this.txtPass.Lines = new string[0];
            this.txtPass.Location = new System.Drawing.Point(368, 220);
            this.txtPass.MaxLength = 32767;
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '*';
            this.txtPass.PromptText = "Enter Password";
            this.txtPass.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPass.SelectedText = "";
            this.txtPass.SelectionLength = 0;
            this.txtPass.SelectionStart = 0;
            this.txtPass.ShortcutsEnabled = true;
            this.txtPass.Size = new System.Drawing.Size(163, 23);
            this.txtPass.TabIndex = 5;
            this.txtPass.UseSelectable = true;
            this.txtPass.WaterMark = "Enter Password";
            this.txtPass.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPass.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // loginAdmin
            // 
            this.loginAdmin.Location = new System.Drawing.Point(470, 320);
            this.loginAdmin.Name = "loginAdmin";
            this.loginAdmin.Size = new System.Drawing.Size(75, 23);
            this.loginAdmin.TabIndex = 6;
            this.loginAdmin.Text = "Log in";
            this.loginAdmin.UseSelectable = true;
            this.loginAdmin.Click += new System.EventHandler(this.MetroButton1_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(69, 359);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(75, 23);
            this.metroButton2.TabIndex = 7;
            this.metroButton2.Text = "Back";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.MetroButton2_Click);
            // 
            // loginCustomer
            // 
            this.loginCustomer.Location = new System.Drawing.Point(418, 281);
            this.loginCustomer.Name = "loginCustomer";
            this.loginCustomer.Size = new System.Drawing.Size(75, 23);
            this.loginCustomer.TabIndex = 8;
            this.loginCustomer.Text = "Log in";
            this.loginCustomer.UseSelectable = true;
            this.loginCustomer.Click += new System.EventHandler(this.LoginCustomer_Click);
            // 
            // loginOwner
            // 
            this.loginOwner.Location = new System.Drawing.Point(510, 281);
            this.loginOwner.Name = "loginOwner";
            this.loginOwner.Size = new System.Drawing.Size(75, 23);
            this.loginOwner.TabIndex = 9;
            this.loginOwner.Text = "Log in";
            this.loginOwner.UseSelectable = true;
            this.loginOwner.Click += new System.EventHandler(this.LoginOwner_Click);
            // 
            // Loginform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 441);
            this.Controls.Add(this.loginOwner);
            this.Controls.Add(this.loginCustomer);
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.loginAdmin);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.txtUN);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Name = "Loginform";
            this.Style = MetroFramework.MetroColorStyle.Default;
            this.Text = "Loginform";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox txtUN;
        private MetroFramework.Controls.MetroTextBox txtPass;
        private MetroFramework.Controls.MetroButton loginAdmin;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton loginCustomer;
        private MetroFramework.Controls.MetroButton loginOwner;
    }
}