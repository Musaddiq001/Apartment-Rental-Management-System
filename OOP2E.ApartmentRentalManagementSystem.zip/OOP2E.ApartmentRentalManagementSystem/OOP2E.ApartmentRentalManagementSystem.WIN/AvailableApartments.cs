﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class AvailableApartments : MetroFramework.Forms.MetroForm
    {
        public AvailableApartments()
        {
            InitializeComponent();
        }

        private void AvailableApartments_Load(object sender, EventArgs e)
        {
            this.Init();
        }
        private void Init()
        {
            txtSearch.Text = txtID.Text = txtID.Text = txtAPID.Text = "";
            this.LoadAvApartmentInfo();
        }

        public void LoadAvApartmentInfo()
        {
            try
            {
                string query = "SELECT AP_ID, ID, Location, Bed, Bath, Balcony, Price, Floor, Type FROM Apartment where Status='To-let';";
                if (!string.IsNullOrEmpty(txtSearch.Text))
                {
                    query = query + " and Location like '%"+txtSearch.Text+"%'";
                }
                DataTable dt = DataAccess.GetDataTable(query);


                dgvAvApartments.AutoGenerateColumns = false;
                dgvAvApartments.DataSource = dt;
                dgvAvApartments.Refresh();
                dgvAvApartments.ClearSelection();
            }

            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void MetroButton4_Click(object sender, EventArgs e)
        {
            this.LoadAvApartmentInfo();
        }

        private void MetroButton3_Click(object sender, EventArgs e)
        {
            this.Init();
        }

        private void DgvAvApartments_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DgvAvApartments_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string apid = dgvAvApartments.Rows[e.RowIndex].Cells["dgvAP_ID"].Value.ToString();
                this.LoadAvApartmentInfos(apid);
            }
        }
        private void LoadAvApartmentInfos(string apid)
        {
            try
            {
                string query = "SELECT AP_ID, ID FROM Apartment WHERE  AP_ID = " + apid;

                DataTable dt = DataAccess.GetDataTable(query);
                if (dt.Rows.Count != 1)
                    return;

                txtAPID.Text = dt.Rows[0]["AP_ID"].ToString();
                txtID.Text = dt.Rows[0]["ID"].ToString();

            }

            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            this.NewApartment();
        }
        public void NewApartment()
        {
            txtAPID.Text = "";
            txtID.Text = "";
            

            dgvAvApartments.ClearSelection();
        }

        private void MetroButton5_Click(object sender, EventArgs e)
        {
            this.insert();
        }
        private void insert()
        {
            string query = "insert into Requested (ID,AP_ID) " +
                "values (" + Int32.Parse(txtID.Text) + "," + Int32.Parse(txtAPID.Text) + ");";
            int ID = DataAccess.InsertQuery(query);
            txtID.Text = ID.ToString();
            MessageBox.Show("Saved");

        }

        private void MetroButton6_Click(object sender, EventArgs e)
        {
            Form1 s1 = new Form1();
            s1.Show();
            this.Visible = false;
        }
    }
}
