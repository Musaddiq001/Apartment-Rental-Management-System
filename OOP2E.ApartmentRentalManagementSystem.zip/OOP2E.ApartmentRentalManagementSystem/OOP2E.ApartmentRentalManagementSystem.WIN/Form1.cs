﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void MetroButton2_Click(object sender, EventArgs e)
        {
            Loginform l1 = new Loginform();
            l1.Show();
            this.Visible = false;
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            SignUp sf1 = new SignUp();
            sf1.Show();
            this.Visible = false;

        }

        private void MetroButton3_Click(object sender, EventArgs e)
        {
            int b = 1;
            int a = 2;
            Loginform l1 = new Loginform(b,a);
            l1.Show();
            this.Visible = false;
        }

        private void MetroButton4_Click(object sender, EventArgs e)
        {
            int b = 1;
            Loginform l1 = new Loginform(b);
            l1.Show();
            this.Visible = false;
        }
    }
}
