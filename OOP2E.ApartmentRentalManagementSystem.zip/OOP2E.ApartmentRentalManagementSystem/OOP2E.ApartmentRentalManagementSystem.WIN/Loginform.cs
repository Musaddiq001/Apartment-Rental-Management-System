﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2E.ApartmentRentalManagementSystem.WIN
{
    public partial class Loginform : MetroFramework.Forms.MetroForm
    {
        public Loginform()
        {
            
            InitializeComponent();
            loginOwner.Visible = false;
            loginCustomer.Visible = false;
        }
        public Loginform(int b)
        {

            InitializeComponent();
            loginAdmin.Visible = false;
            loginCustomer.Visible = false;
        }

        public Loginform(int b,int a)
        {

            InitializeComponent();
            loginAdmin.Visible = false;
            loginOwner.Visible = false;
        }


        private void MetroButton2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Visible = false;
        }

        private void MetroTextBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            string un = txtUN.Text;
            string pass = txtPass.Text;

            if (un.Equals("Musaddiq") && pass.Equals("123"))
            {
                AdminFrame a1 = new AdminFrame();
                a1.Show();
                this.Visible = false;
            }
            else
                MessageBox.Show("Invalid id or password");
        }


        private void MetroRadioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void LoginOwner_Click(object sender, EventArgs e)
        {
            string query = "select * from userinfo where Name='" + txtUN.Text + "' and Password='" + txtPass.Text + "' and Type='Owner'";

            DataTable dt = DataAccess.GetDataTable(query);


            int c = dt.Rows.Count;
            if (c == 1)
            {
                OwnerView o1 = new OwnerView();
                o1.Show();
                this.Visible = false;
            }
            else
            {
                MessageBox.Show("Invalid Information");
            }
            
        }

        private void LoginCustomer_Click(object sender, EventArgs e)
        {

            string query = "select * from userinfo where Name='" + txtUN.Text + "' and Password='" + txtPass.Text + "' and Type='Customer'";

            DataTable dt = DataAccess.GetDataTable(query);


            int c = dt.Rows.Count;
            if (c == 1)
            {
                CustomerView c1 = new CustomerView();
                c1.Show();
                this.Hide();


            }
            else
            {
                MessageBox.Show("Invalid Information");
            }
            
        }
    }
}

